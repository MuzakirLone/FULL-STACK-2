Learning Outcomes:
1. Learned how to make a Vite, React Application
2. Learned how to use github and git to commit and push files to a repository
3. Learned how to deploy an web application on netlify.
